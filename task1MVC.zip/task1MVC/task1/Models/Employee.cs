﻿using System.ComponentModel.DataAnnotations;

namespace task1.Models
{
    public class Employee
    {
        [Key]   
        public int EmployeeId { get; set; }
        public string Name { get; set; }
        public DateTime BirthDate { get; set; }
        public string PhoneNumber { get; set; }
        public string NationalId { get; set; }
        public string Nationality { get; set; }
        public string MaritalStatus { get; set; }
        public string PersonalPhoto { get; set; }
        public DateTime EntryDate { get; set; }
        public string Password { get; set; }
        public int DepartmentId { get; set; }
        public Department Department { get; set; }
       
    }
}
