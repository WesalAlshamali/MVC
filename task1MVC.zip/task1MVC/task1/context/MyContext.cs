﻿using Microsoft.EntityFrameworkCore;
using task1.Models;

namespace task1.context
{
    public class MyContext : DbContext
    {

        public MyContext(DbContextOptions<MyContext> options) : base(options) { }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            var builder = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: true);
            IConfigurationRoot configurationRoot = builder.Build();
            var constring = configurationRoot.GetConnectionString("my connection");
            optionsBuilder.UseSqlServer(constring);


        }
        public DbSet<Department> Departments { get; set; }
        public DbSet<feedback> Feedbacks { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<taskes> Taskes { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);


        }
    }
}
